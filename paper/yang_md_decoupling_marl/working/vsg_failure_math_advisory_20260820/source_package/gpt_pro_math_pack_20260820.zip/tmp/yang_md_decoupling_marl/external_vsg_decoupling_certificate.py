#!/usr/bin/env python3
"""
VSG common/differential decoupling certificate and controller scaffold.

Replace the example matrices/waveforms in main() with the archived linearization.
The script implements:
  1) exact frozen-model common/differential decoupling tests;
  2) leading cross-channel Markov moments;
  3) feasibility of static M/D homogenization under the documented boxes;
  4) the sharp two-frequency selectivity bound for a first-order lead/high-pass;
  5) fixed-parameter finite-horizon simulation and cross-energy evaluation;
  6) a local ring-edge second-order band-pass controller scaffold.

Dependencies: numpy, scipy.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional, Sequence, Tuple

import numpy as np
from numpy.typing import NDArray
from scipy import linalg, signal

Array = NDArray[np.float64]


def common_differential_basis(n: int = 4) -> Tuple[Array, Array, Array, Array]:
    """Return q, Qd, Pc, Pd with q=1/sqrt(n)*1 and Qd orthonormal on 1^perp."""
    if n < 2:
        raise ValueError("n must be at least 2")
    q = np.ones((n, 1), dtype=float) / np.sqrt(n)
    # Null space of q^T; scipy returns an orthonormal basis.
    Qd = linalg.null_space(q.T)
    Pc = q @ q.T
    Pd = np.eye(n) - Pc
    return q, Qd, Pc, Pd


def validate_model(L: Array, M: Sequence[float], D: Sequence[float]) -> None:
    L = np.asarray(L, dtype=float)
    M = np.asarray(M, dtype=float)
    D = np.asarray(D, dtype=float)
    n = M.size
    if L.shape != (n, n) or D.shape != (n,):
        raise ValueError("Expected L (n,n), M (n,), D (n,)")
    if np.any(M <= 0) or np.any(D <= 0):
        raise ValueError("M and D must be strictly positive")


def decoupling_residuals(L: Array, M: Sequence[float], D: Sequence[float]) -> dict[str, float]:
    """
    Residuals for the exact frozen-model theorem.

    Exact arithmetic common/differential decoupling holds when Pc commutes with
    L, diag(M), and diag(D). For a balanced Laplacian and diagonal M,D this is
    equivalent to homogeneous M and homogeneous D.
    """
    validate_model(L, M, D)
    Mv = np.asarray(M, dtype=float)
    Dv = np.asarray(D, dtype=float)
    n = Mv.size
    one = np.ones(n)
    _, _, Pc, _ = common_differential_basis(n)
    Mm = np.diag(Mv)
    Dm = np.diag(Dv)

    def rel_norm(X: Array, scale: Array) -> float:
        return float(linalg.norm(X, 2) / max(1.0, linalg.norm(scale, 2)))

    return {
        "L_right_balance": float(linalg.norm(L @ one) / max(1.0, linalg.norm(L, 2))),
        "L_left_balance": float(linalg.norm(one @ L) / max(1.0, linalg.norm(L, 2))),
        "commutator_L": rel_norm(Pc @ L - L @ Pc, L),
        "commutator_M": rel_norm(Pc @ Mm - Mm @ Pc, Mm),
        "commutator_D": rel_norm(Pc @ Dm - Dm @ Pc, Dm),
        "relative_spread_M": float(np.std(Mv) / np.mean(Mv)),
        "relative_spread_D": float(np.std(Dv) / np.mean(Dv)),
    }


def frozen_transfer(s: complex, L: Array, M: Sequence[float], D: Sequence[float],
                    omega_n: float = 2.0 * np.pi * 60.0) -> Array:
    """G_omega,w(s) = s (s^2 M + s D + omega_n L)^(-1)."""
    validate_model(L, M, D)
    Mm = np.diag(np.asarray(M, dtype=float))
    Dm = np.diag(np.asarray(D, dtype=float))
    P = (s * s) * Mm + s * Dm + omega_n * np.asarray(L, dtype=float)
    return s * linalg.solve(P, np.eye(P.shape[0]), assume_a="gen")


def cross_transfer_blocks(s: complex, L: Array, M: Sequence[float], D: Sequence[float],
                          omega_n: float = 2.0 * np.pi * 60.0) -> Tuple[Array, Array]:
    """Return differential<-common and common<-differential frozen transfer blocks."""
    n = len(M)
    q, Qd, _, _ = common_differential_basis(n)
    G = frozen_transfer(s, L, M, D, omega_n)
    T_dc = Qd.T @ G @ q
    T_cd = q.T @ G @ Qd
    return T_dc, T_cd


def leading_cross_moments(M: Sequence[float], D: Sequence[float]) -> dict[str, Array | float]:
    """
    High-frequency cross moments:
      G(s) = M^-1/s - M^-1 D M^-1/s^2 + O(s^-3).
    These moments are zero exactly when the corresponding diagonal quantities
    are homogeneous in arithmetic common/differential coordinates.
    """
    Mv = np.asarray(M, dtype=float)
    Dv = np.asarray(D, dtype=float)
    n = Mv.size
    q, Qd, Pc, Pd = common_differential_basis(n)
    Minv = np.diag(1.0 / Mv)
    second = Minv @ np.diag(Dv) @ Minv
    J1_dc = Qd.T @ Minv @ q
    J1_cd = q.T @ Minv @ Qd
    J2_dc = -Qd.T @ second @ q
    J2_cd = -q.T @ second @ Qd
    invM = 1.0 / Mv
    d_over_m2 = Dv / (Mv * Mv)
    return {
        "J1_d_from_c": J1_dc,
        "J1_c_from_d": J1_cd,
        "J2_d_from_c": J2_dc,
        "J2_c_from_d": J2_cd,
        "variance_inverse_M": float(np.var(invM)),
        "variance_D_over_M2": float(np.var(d_over_m2)),
        "projected_inverse_M_norm": float(linalg.norm(Pd @ Minv @ Pc, "fro")),
    }


def homogeneous_intersection(
    M0: Sequence[float],
    D0: Sequence[float],
    delta_M: Tuple[float, float] = (-200.0, 600.0),
    delta_D: Tuple[float, float] = (-200.0, 600.0),
    M_floor: float = 20.0,
    D_floor: float = 10.0,
) -> dict[str, float | bool]:
    """Compute whether all machines can be moved to common M* and D* values."""
    M0v = np.asarray(M0, dtype=float)
    D0v = np.asarray(D0, dtype=float)
    M_lo = np.maximum(M_floor, M0v + delta_M[0])
    M_hi = M0v + delta_M[1]
    D_lo = np.maximum(D_floor, D0v + delta_D[0])
    D_hi = D0v + delta_D[1]
    common_M_lo, common_M_hi = float(np.max(M_lo)), float(np.min(M_hi))
    common_D_lo, common_D_hi = float(np.max(D_lo)), float(np.min(D_hi))
    M_ok = common_M_lo <= common_M_hi
    D_ok = common_D_lo <= common_D_hi

    # Moment-matching starting point for common-mode RoCoF and early damping.
    harmonic_M = float(len(M0v) / np.sum(1.0 / M0v))
    matched_D = float(harmonic_M**2 * np.mean(D0v / (M0v**2)))
    M_star = float(np.clip(harmonic_M, common_M_lo, common_M_hi)) if M_ok else np.nan
    D_star = float(np.clip(matched_D, common_D_lo, common_D_hi)) if D_ok else np.nan
    return {
        "M_feasible": M_ok,
        "D_feasible": D_ok,
        "M_common_lo": common_M_lo,
        "M_common_hi": common_M_hi,
        "D_common_lo": common_D_lo,
        "D_common_hi": common_D_hi,
        "M_star_moment_match": M_star,
        "D_star_moment_match": D_star,
    }


def first_order_magnitude(K: float, z: float, p: float, omega: float) -> float:
    if K < 0 or z < 0 or p <= 0 or omega < 0:
        raise ValueError("Require K,z,omega >= 0 and p > 0")
    return float(K * np.sqrt((omega * omega + z * z) / (omega * omega + p * p)))


def first_order_selectivity_bound(omega_mode: float, omega_probe: float) -> float:
    """Sharp sup |H(j wm)|/|H(j wx)| for K(s+z)/(s+p), p,z>0, wm>wx>0."""
    if not (omega_mode > omega_probe > 0):
        raise ValueError("Require omega_mode > omega_probe > 0")
    return float(omega_mode / omega_probe)


def first_order_ratio(z: float, p: float, omega_mode: float, omega_probe: float) -> float:
    if z < 0 or p <= 0:
        raise ValueError("Require z >= 0, p > 0")
    num = (omega_mode**2 + z**2) * (omega_probe**2 + p**2)
    den = (omega_mode**2 + p**2) * (omega_probe**2 + z**2)
    return float(np.sqrt(num / den))


def fixed_model_matrices(L: Array, M: Sequence[float], D: Sequence[float],
                         omega_n: float = 2.0 * np.pi * 60.0) -> Tuple[Array, Array]:
    validate_model(L, M, D)
    Mv = np.asarray(M, dtype=float)
    Dv = np.asarray(D, dtype=float)
    n = Mv.size
    Minv = np.diag(1.0 / Mv)
    A = np.block([
        [np.zeros((n, n)), omega_n * np.eye(n)],
        [-Minv @ np.asarray(L, dtype=float), -Minv @ np.diag(Dv)],
    ])
    B = np.vstack([np.zeros((n, n)), Minv])
    return A, B


def zoh_discretize(A: Array, B: Array, dt: float) -> Tuple[Array, Array]:
    if dt <= 0:
        raise ValueError("dt must be positive")
    n, m = B.shape
    aug = np.block([[A, B], [np.zeros((m, n + m))]])
    E = linalg.expm(aug * dt)
    return E[:n, :n], E[:n, n:]


def simulate_fixed(L: Array, M: Sequence[float], D: Sequence[float], w: Array,
                   dt: float = 0.2, omega_n: float = 2.0 * np.pi * 60.0,
                   x0: Optional[Array] = None) -> Tuple[Array, Array, Array]:
    """Simulate a fixed M,D model under zero-order-held w[k,:]."""
    w = np.asarray(w, dtype=float)
    if w.ndim != 2:
        raise ValueError("w must have shape (steps,n)")
    n = w.shape[1]
    A, B = fixed_model_matrices(L, M, D, omega_n)
    Ad, Bd = zoh_discretize(A, B, dt)
    x = np.zeros(2 * n) if x0 is None else np.asarray(x0, dtype=float).copy()
    xs = [x.copy()]
    for wk in w:
        x = Ad @ x + Bd @ wk
        xs.append(x.copy())
    xs_arr = np.asarray(xs)
    theta = xs_arr[:, :n]
    omega = xs_arr[:, n:]
    return xs_arr, theta, omega


def cross_energy_fixed(
    L: Array,
    M: Sequence[float],
    D: Sequence[float],
    common_probes: Iterable[Array],
    differential_probes: Iterable[Array],
    dt: float = 0.2,
    omega_n: float = 2.0 * np.pi * 60.0,
) -> dict[str, float]:
    """
    Evaluate E_{d<-c}+E_{c<-d} for supplied probe waveforms.
    Each waveform has shape (steps,n). Supply both signs explicitly when needed.
    """
    n = len(M)
    q, Qd, _, _ = common_differential_basis(n)
    E_dc = 0.0
    E_cd = 0.0
    for w in common_probes:
        _, _, omega = simulate_fixed(L, M, D, w, dt, omega_n)
        zd = omega @ Qd
        E_dc += float(dt * np.sum(zd * zd))
    for w in differential_probes:
        _, _, omega = simulate_fixed(L, M, D, w, dt, omega_n)
        zc = omega @ q
        E_cd += float(dt * np.sum(zc * zc))
    return {"E_d_from_c": E_dc, "E_c_from_d": E_cd, "E_cross": E_dc + E_cd}


def ring_incidence(n: int = 4) -> Array:
    """Oriented incidence matrix B (n nodes, n ring edges)."""
    if n < 3:
        raise ValueError("A ring requires n>=3")
    B = np.zeros((n, n))
    for e in range(n):
        i, j = e, (e + 1) % n
        B[i, e] = 1.0
        B[j, e] = -1.0
    return B


@dataclass
class RingBandpassController:
    """
    Local edge controller for acceleration commands:
       v = -B_ring F(z) B_ring^T omega,
       p_i = M_i v_i.

    With homogeneous M, this is also a passive zero-sum physical-power law.
    For heterogeneous M it remains exactly transparent to arithmetic common
    acceleration (1^T v=0), but closed-loop stability must be checked numerically.
    """
    n: int = 4
    dt: float = 0.2
    f0_hz: float = 0.4
    zeta: float = 0.35
    gain: float = 1.0

    def __post_init__(self) -> None:
        if self.dt <= 0 or self.f0_hz <= 0 or self.zeta <= 0 or self.gain < 0:
            raise ValueError("Invalid controller parameters")
        self.Bring = ring_incidence(self.n)
        w0 = 2.0 * np.pi * self.f0_hz
        # F(s)=gain*(2*zeta*w0*s)/(s^2+2*zeta*w0*s+w0^2), peak gain at w0.
        num = [self.gain * 2.0 * self.zeta * w0, 0.0]
        den = [1.0, 2.0 * self.zeta * w0, w0 * w0]
        Ac, Bc, Cc, Dc = signal.tf2ss(num, den)
        Ad, Bd, Cd, Dd, _ = signal.cont2discrete((Ac, Bc, Cc, Dc), self.dt, method="bilinear")
        self.Ad = np.asarray(Ad, dtype=float)
        self.Bd = np.asarray(Bd, dtype=float)
        self.Cd = np.asarray(Cd, dtype=float)
        self.Dd = np.asarray(Dd, dtype=float)
        self.xe = np.zeros((self.Bring.shape[1], self.Ad.shape[0]))

    def reset(self) -> None:
        self.xe.fill(0.0)

    def step(self, omega: Sequence[float], M: Sequence[float]) -> Tuple[Array, Array]:
        omega_v = np.asarray(omega, dtype=float)
        Mv = np.asarray(M, dtype=float)
        if omega_v.shape != (self.n,) or Mv.shape != (self.n,):
            raise ValueError("omega and M must have shape (n,)")
        edge_delta = self.Bring.T @ omega_v
        edge_out = np.empty(self.Bring.shape[1])
        for e, ue in enumerate(edge_delta):
            # Output from current state/input, then update state.
            edge_out[e] = float((self.Cd @ self.xe[e]).item() + self.Dd.item() * ue)
            self.xe[e] = self.Ad @ self.xe[e] + self.Bd[:, 0] * ue
        acceleration_cmd = -self.Bring @ edge_out
        power_cmd = Mv * acceleration_cmd
        return acceleration_cmd, power_cmd


def rate_limit(target: Array, previous: Array, max_step: float | Array,
               lower: Optional[Array] = None, upper: Optional[Array] = None) -> Array:
    target = np.asarray(target, dtype=float)
    previous = np.asarray(previous, dtype=float)
    max_step_arr = np.asarray(max_step, dtype=float)
    out = previous + np.clip(target - previous, -max_step_arr, max_step_arr)
    if lower is not None:
        out = np.maximum(out, np.asarray(lower, dtype=float))
    if upper is not None:
        out = np.minimum(out, np.asarray(upper, dtype=float))
    return out


def demo() -> None:
    # Demonstration only. Replace with the archived Kundur linearization.
    n = 4
    L = np.array([
        [2.0, -1.0, 0.0, -1.0],
        [-1.0, 2.0, -1.0, 0.0],
        [0.0, -1.0, 2.0, -1.0],
        [-1.0, 0.0, -1.0, 2.0],
    ])
    M = np.array([120.0, 180.0, 260.0, 340.0])
    D = np.array([80.0, 130.0, 180.0, 240.0])

    print("Decoupling residuals:")
    for k, v in decoupling_residuals(L, M, D).items():
        print(f"  {k}: {v:.6g}")
    print("\nLeading cross moments:")
    for k, v in leading_cross_moments(M, D).items():
        print(f"  {k}: {v}")
    print("\nHomogeneous intersection:")
    for k, v in homogeneous_intersection(M, D).items():
        print(f"  {k}: {v}")

    wm = 2.0 * np.pi * 0.4
    wx = 2.0 * np.pi * 0.084
    print(f"\nFirst-order maximum two-frequency selectivity: {first_order_selectivity_bound(wm, wx):.4f}")

    ctrl = RingBandpassController(n=n, dt=0.2, f0_hz=0.4, zeta=0.35, gain=1.0)
    acc, p = ctrl.step([0.01, -0.01, 0.005, -0.005], M)
    print("\nController one-step acceleration command:", acc)
    print("Controller one-step power command:", p)
    print("Sum acceleration command (must be ~0):", float(np.sum(acc)))


if __name__ == "__main__":
    demo()