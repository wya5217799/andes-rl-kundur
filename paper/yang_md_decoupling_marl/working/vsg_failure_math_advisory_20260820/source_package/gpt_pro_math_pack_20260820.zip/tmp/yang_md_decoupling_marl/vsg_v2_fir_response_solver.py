#!/usr/bin/env python3
"""Finite-window affine-response solver for a local FIR/Youla VSG controller.

The exact DAE/linearized model is used upstream to identify affine trajectory maps

    y_s,j(q) = b_s,j + A_s,j @ q

where q stacks the local FIR/Youla coefficients.  This script then solves the
convex epigraph problem

    min gamma
    s.t. ||b_d[s] + A_d[s] q||_2 <= gamma*sqrt(0.95*E_d0[s])
         ||b_c[s] + A_c[s] q||_2 <= gamma*sqrt(1.10*E_c0[s])
         optional affine box/slew/guard trajectory constraints.

A solution with gamma <= 1 enters the V2 Q={r_d<=0.95,r_cross<=1.10}
quadrant on every supplied profile.  SciPy SLSQP is used so the script has few
dependencies.  Because the mathematical problem is convex, a converged KKT point
is globally optimal; for a formal conic dual certificate, transcribe the same
constraints to CVXPY/Clarabel.

NPZ keys
--------
Required:
  A_d       : (n_profile, n_sample_d, n_q)
  b_d       : (n_profile, n_sample_d)
  E_d0      : (n_profile,)
  A_cross   : (n_profile, n_sample_c, n_q)
  b_cross   : (n_profile, n_sample_c)
  E_cross0  : (n_profile,)

Optional affine elementwise constraints:
  A_action, b_action, action_lower, action_upper
  A_slew,   b_slew,   slew_lower,   slew_upper
  A_guard,  b_guard,  guard_lower,  guard_upper

Each optional A has shape (..., n_q); b/lower/upper have shape A.shape[:-1].
Use +/-inf for one-sided bounds.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

import numpy as np
from scipy.optimize import minimize


@dataclass
class AffineBlock:
    A: np.ndarray
    b: np.ndarray
    lower: np.ndarray
    upper: np.ndarray
    name: str

    def validate(self, n_q: int) -> None:
        if self.A.shape[-1] != n_q:
            raise ValueError(f"{self.name}: last A dimension must be n_q={n_q}")
        shape = self.A.shape[:-1]
        for label, arr in (("b", self.b), ("lower", self.lower), ("upper", self.upper)):
            if arr.shape != shape:
                raise ValueError(f"{self.name}: {label} shape {arr.shape} != {shape}")


@dataclass
class ProblemData:
    A_d: np.ndarray
    b_d: np.ndarray
    E_d0: np.ndarray
    A_c: np.ndarray
    b_c: np.ndarray
    E_c0: np.ndarray
    affine_blocks: Tuple[AffineBlock, ...] = ()

    @property
    def n_q(self) -> int:
        return int(self.A_d.shape[-1])

    @property
    def n_profile(self) -> int:
        return int(self.A_d.shape[0])

    def validate(self) -> None:
        if self.A_d.ndim != 3 or self.A_c.ndim != 3:
            raise ValueError("A_d and A_cross must be rank-3")
        if self.A_d.shape[0] != self.A_c.shape[0]:
            raise ValueError("profile counts differ")
        if self.b_d.shape != self.A_d.shape[:-1]:
            raise ValueError("b_d shape mismatch")
        if self.b_c.shape != self.A_c.shape[:-1]:
            raise ValueError("b_cross shape mismatch")
        if self.E_d0.shape != (self.n_profile,) or self.E_c0.shape != (self.n_profile,):
            raise ValueError("baseline energy shapes must be (n_profile,)")
        if np.any(self.E_d0 <= 0) or np.any(self.E_c0 <= 0):
            raise ValueError("baseline energies must be positive")
        if self.A_c.shape[-1] != self.n_q:
            raise ValueError("A_d and A_cross use different n_q")
        for block in self.affine_blocks:
            block.validate(self.n_q)


def _optional_block(npz: Any, prefix: str, n_q: int) -> Optional[AffineBlock]:
    a_key = f"A_{prefix}"
    if a_key not in npz:
        return None
    A = np.asarray(npz[a_key], dtype=float)
    b = np.asarray(npz[f"b_{prefix}"], dtype=float)
    lower = np.asarray(npz[f"{prefix}_lower"], dtype=float)
    upper = np.asarray(npz[f"{prefix}_upper"], dtype=float)
    block = AffineBlock(A=A, b=b, lower=lower, upper=upper, name=prefix)
    block.validate(n_q)
    return block


def load_problem(path: Path) -> ProblemData:
    with np.load(path, allow_pickle=False) as z:
        A_d = np.asarray(z["A_d"], dtype=float)
        b_d = np.asarray(z["b_d"], dtype=float)
        E_d0 = np.asarray(z["E_d0"], dtype=float)
        A_c = np.asarray(z["A_cross"], dtype=float)
        b_c = np.asarray(z["b_cross"], dtype=float)
        E_c0 = np.asarray(z["E_cross0"], dtype=float)
        n_q = A_d.shape[-1]
        blocks = tuple(
            block
            for block in (
                _optional_block(z, "action", n_q),
                _optional_block(z, "slew", n_q),
                _optional_block(z, "guard", n_q),
            )
            if block is not None
        )
    problem = ProblemData(A_d, b_d, E_d0, A_c, b_c, E_c0, blocks)
    problem.validate()
    return problem


def _ratios(problem: ProblemData, q: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    yd = np.einsum("snq,q->sn", problem.A_d, q) + problem.b_d
    yc = np.einsum("snq,q->sn", problem.A_c, q) + problem.b_c
    rd = np.sum(yd * yd, axis=1) / problem.E_d0
    rc = np.sum(yc * yc, axis=1) / problem.E_c0
    return rd, rc


def solve(
    problem: ProblemData,
    *,
    target_d: float = 0.95,
    target_cross: float = 1.10,
    q_bound: float = 10.0,
    maxiter: int = 4000,
    ftol: float = 1e-11,
    starts: int = 5,
    seed: int = 17,
) -> Dict[str, Any]:
    problem.validate()
    if target_d <= 0 or target_cross <= 0 or q_bound <= 0:
        raise ValueError("targets and q_bound must be positive")

    n_q = problem.n_q
    sqrt_d = np.sqrt(target_d * problem.E_d0)
    sqrt_c = np.sqrt(target_cross * problem.E_c0)

    def objective(x: np.ndarray) -> float:
        return float(x[-1])

    def objective_jac(x: np.ndarray) -> np.ndarray:
        g = np.zeros_like(x)
        g[-1] = 1.0
        return g

    def con_energy(x: np.ndarray) -> np.ndarray:
        q = x[:-1]
        gamma = x[-1]
        yd = np.einsum("snq,q->sn", problem.A_d, q) + problem.b_d
        yc = np.einsum("snq,q->sn", problem.A_c, q) + problem.b_c
        return np.concatenate(
            [gamma * sqrt_d - np.linalg.norm(yd, axis=1),
             gamma * sqrt_c - np.linalg.norm(yc, axis=1)]
        )

    constraints = [{"type": "ineq", "fun": con_energy}]

    for block in problem.affine_blocks:
        finite_lower = np.isfinite(block.lower)
        finite_upper = np.isfinite(block.upper)

        if np.any(finite_lower):
            A_l = block.A[finite_lower]
            b_l = block.b[finite_lower]
            l_l = block.lower[finite_lower]

            def lower_fun(x: np.ndarray, A=A_l, b=b_l, lower=l_l) -> np.ndarray:
                return (A @ x[:-1] + b) - lower

            constraints.append({"type": "ineq", "fun": lower_fun})

        if np.any(finite_upper):
            A_u = block.A[finite_upper]
            b_u = block.b[finite_upper]
            u_u = block.upper[finite_upper]

            def upper_fun(x: np.ndarray, A=A_u, b=b_u, upper=u_u) -> np.ndarray:
                return upper - (A @ x[:-1] + b)

            constraints.append({"type": "ineq", "fun": upper_fun})

    bounds = [(-q_bound, q_bound)] * n_q + [(0.0, None)]
    rng = np.random.default_rng(seed)
    initial_points = [np.concatenate([np.zeros(n_q), [2.0]])]
    for _ in range(max(0, starts - 1)):
        q0 = rng.uniform(-0.1 * q_bound, 0.1 * q_bound, size=n_q)
        initial_points.append(np.concatenate([q0, [2.0]]))

    best = None
    records = []
    for index, x0 in enumerate(initial_points):
        result = minimize(
            objective,
            x0,
            jac=objective_jac,
            method="SLSQP",
            bounds=bounds,
            constraints=constraints,
            options={"maxiter": maxiter, "ftol": ftol, "disp": False},
        )
        record = {
            "start": index,
            "success": bool(result.success),
            "status": int(result.status),
            "message": str(result.message),
            "objective_gamma": float(result.fun),
            "max_constraint_violation": float(max(0.0, -np.min(con_energy(result.x)))),
        }
        records.append(record)
        if best is None or (
            record["max_constraint_violation"] <= 1e-6
            and (best[0]["max_constraint_violation"] > 1e-6 or result.fun < best[1].fun)
        ):
            best = (record, result)

    assert best is not None
    best_record, result = best
    q = np.asarray(result.x[:-1], dtype=float)
    gamma = float(result.x[-1])
    rd, rc = _ratios(problem, q)

    affine_summary: Dict[str, Any] = {}
    for block in problem.affine_blocks:
        values = np.einsum("...q,q->...", block.A, q) + block.b
        lower_violation = np.maximum(block.lower - values, 0.0)
        upper_violation = np.maximum(values - block.upper, 0.0)
        affine_summary[block.name] = {
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "max_violation": float(max(np.max(lower_violation), np.max(upper_violation))),
        }

    return {
        "solver": "scipy.optimize.SLSQP",
        "convex_problem": True,
        "formal_dual_certificate": False,
        "success": bool(result.success and best_record["max_constraint_violation"] <= 1e-6),
        "message": str(result.message),
        "gamma": gamma,
        "gamma_squared": gamma * gamma,
        "enters_Q": bool(np.max(rd) <= target_d + 1e-6 and np.max(rc) <= target_cross + 1e-6),
        "target_d": target_d,
        "target_cross": target_cross,
        "worst_r_d": float(np.max(rd)),
        "worst_r_cross": float(np.max(rc)),
        "r_d_by_profile": rd.tolist(),
        "r_cross_by_profile": rc.tolist(),
        "q": q.tolist(),
        "affine_constraints": affine_summary,
        "starts": records,
    }


def write_demo(path: Path) -> None:
    """Write a small feasible synthetic problem for installation testing."""
    rng = np.random.default_rng(3)
    n_profile, n_sample, n_q = 3, 8, 4
    A_d = rng.normal(scale=0.08, size=(n_profile, n_sample, n_q))
    A_c = rng.normal(scale=0.08, size=(n_profile, n_sample, n_q))
    q_star = np.array([0.45, -0.30, 0.25, -0.15])
    # Build baseline responses for which q_star suppresses energy strongly.
    b_d = -A_d @ q_star + rng.normal(scale=0.02, size=(n_profile, n_sample))
    b_c = -A_c @ q_star + rng.normal(scale=0.02, size=(n_profile, n_sample))
    E_d0 = np.sum((b_d + 0.15) ** 2, axis=1) + 0.05
    E_c0 = np.sum((b_c + 0.15) ** 2, axis=1) + 0.05

    A_action = rng.normal(scale=0.1, size=(n_profile, 10, n_q))
    b_action = np.zeros((n_profile, 10))
    action_lower = -np.ones((n_profile, 10))
    action_upper = np.ones((n_profile, 10))

    np.savez_compressed(
        path,
        A_d=A_d,
        b_d=b_d,
        E_d0=E_d0,
        A_cross=A_c,
        b_cross=b_c,
        E_cross0=E_c0,
        A_action=A_action,
        b_action=b_action,
        action_lower=action_lower,
        action_upper=action_upper,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", type=Path, help="NPZ affine-response case")
    parser.add_argument("--result", type=Path, default=Path("fir_response_result.json"))
    parser.add_argument("--target-d", type=float, default=0.95)
    parser.add_argument("--target-cross", type=float, default=1.10)
    parser.add_argument("--q-bound", type=float, default=10.0)
    parser.add_argument("--starts", type=int, default=5)
    parser.add_argument("--write-demo", type=Path, help="write a synthetic demo NPZ and exit")
    args = parser.parse_args()

    if args.write_demo:
        write_demo(args.write_demo)
        print(f"wrote demo: {args.write_demo}")
        return
    if args.case is None:
        parser.error("--case is required unless --write-demo is used")

    problem = load_problem(args.case)
    result = solve(
        problem,
        target_d=args.target_d,
        target_cross=args.target_cross,
        q_bound=args.q_bound,
        starts=args.starts,
    )
    text = json.dumps(result, ensure_ascii=False, indent=2)
    args.result.write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
